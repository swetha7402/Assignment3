
const express = require('express');
const path = require('path');
const fileUpload = require('express-fileupload');
const mongoose = require('mongoose');
const session = require('express-session');

const {check, validationResult} = require('express-validator'); 

// connect to mongoose database and creating the database name 
mongoose.connect('mongodb://localhost:27017/internet',{
    useNewUrlParser: true,
    useUnifiedTopology: true
});
 
// creating the  model for the database for send the information 
const data = mongoose.model('data', {
    Name : String,
    Email : String,
    Description : String,
    ImageName : String
});

//creating the another model to login and perform the operations on the database
const customer = mongoose.model('customer', {
    customername: String,
    customerpassword : String
});

var myApp = express();

//creating the session 
myApp.use(session({
    secret: 'magic',
    resave: false,
    saveUninitialized: true
}));


myApp.use(express.urlencoded({extended:false})); 
myApp.use(fileUpload());
 
myApp.set('views', path.join(__dirname, 'views'));
myApp.use(express.static(__dirname+'/public'));
myApp.set('view engine', 'ejs');

//rendering the home page here 
myApp.get('/',function(req, res){
    res.render('home');
});
//renderin the information page here
myApp.get('/info',function(req, res){
    res.render('info'); 
});
//rendering the login page here
myApp.get('/login',function(req, res){
   res.render('login'); });

//writing the code for login into the account 
   myApp.post('/login', function(req, res){
    // accessing the clientname and clientpassword
    var customername = req.body.customername;
    var  customerpassword= req.body.customerpassword;

    // finding details in the database
    customer.findOne({customername:customername, customerpassword: customerpassword}).exec(function(err, customer){
        // seting up the session variables for logged in for customers
        console.log('Errors: ' + err);
        if(customer){
            req.session.customername = customer.customername; //matching the credentials 
            req.session.loggedIn = true;
            // redirect to dashboard
            res.redirect('/dashboard');
        }
        else{
            res.redirect('/login'); // if you want to  redirect the user to login
            // along with  rendering login form with errors
        }
    });
});

//rendring the dashboard data
myApp.get('/dashboard',function(req, res){
    if(req.session.loggedIn){ // displaying all the entered data
        data.find({}).exec(function(err, Data){
            console.log(err); // displaying the errors in the console
            console.log(Data);
            res.render('dashboard', {Data:Data}); 
        });
    }
    else{
        res.redirect('/login'); // redirecting to the login page 
    }
});

myApp.get('/logout', function(req, res){
    // delete  the whole session
    req.session.customername = ''; //here we are just resetting the whole data to null
    req.session.loggedIn = false;
    res.redirect('/login');
});

//printing the data by id 
myApp.get('/print/:dataid', function(req, res){
    
    var dataId = req.params.dataid;
    data.findOne({_id: dataId}).exec(function(err, data){ // finding the data by id
        res.render('data', data); // rendering data.ejs with the data from data
    });
})

//rendering the thankyou page for updated information
myApp.get('/thankyou/:dataid', function(req, res){
    var dataId = req.params.dataid;
    data.findOne({_id: dataId}).exec(function(err, data){
        res.render('thankyou', data); // rendering the thankyou page in the dtaa
    });
})

//deleting the data by finding an deleting the id
myApp.get('/delete/:dataid', function(req, res){
//this will delete the data premenantly
    var dataId = req.params.dataid;
    data.findByIdAndDelete({_id: dataId}).exec(function(err, data){
        res.render('remove', data); // displaying the removing page after deleting the data
    });
})

// view just display the whole data of the entered forrm again
myApp.get('/view/:dataid', function(req, res){
    
    var dataId = req.params.dataid;
    data.findOne({_id: dataId}).exec(function(err, data){
        res.render('view', data); // render view.ejs with data from data
    });
})

// this form is used to update the information and gives a chance to edit the info 
myApp.get('/edit/:dataid', function(req, res){
    
    var dataId = req.params.dataid;
    data.findOne({_id: dataId}).exec(function(err, data){
        console.log(err);
        res.render('edit', data); // rendering the edit.ejs from data with data
    });
})

 // first we validate this and passing this process information to the editprocess
myApp.post('/process',[
    check('Name', 'Please enter firstname and lastnme').notEmpty(),//checking whether the name is empty or not if y displays error
    check('Email', 'Please enter a valid email').isEmail(),//validating the email  for the correct format
    check('Description', 'Please enter a description.').not().isEmpty(), // validating if it empty or not if yes displays error
], function(req,res){

    // checks the  errors
    const errors = validationResult(req);
    console.log(errors); // print the errors for the console
    if(!errors.isEmpty()) // if error is not empty execute the condition below 
    {
        res.render('home',{err: errors.array()});
    }
    else // if the errors are null execute the below data
    {
        //fetch all the data fields
        var Name = req.body.Name; // the main name attribute 
        var Email = req.body.Email;
        var Description = req.body.Description;

        // here we are searching and getting the file 
        var ImageName = req.files.Image.name;
        var ImageFile = req.files.Image; // this is a temporary file in buffer.

        
        // checks if the files are present or else gerenrate  a unique number as id  used for operations
        var ImagePath = 'public/images/' + ImageName;
        // moving the temporary file to a permanent location
        ImageFile.mv(ImagePath, function(err){
            console.log(err);
        });

        // creating an object with the data to send to the view
        var pageData = {
            Name : Name,
            Email : Email,
            Description : Description,
            ImageName : ImageName
        }

        // creating an object from the model to save to monog db
        var datas = new data(pageData);
        // save it to monog db
            datas.save();

        // send the data to the view and render it
        res.render('data', pageData);
    }
});
//creating the process for editing the form 
myApp.post('/editprocess/:dataid', function(req,res){
    if(!req.session.loggedIn){
        res.redirect('/login');
    } 
    else{
        //fetch all the form fields form the form
        var Name = req.body.Name; // sending the info that is user entered by creating the new one
        var Email = req.body.Email;// ''
        var Description = req.body.Description; // ''
        var ImageName = req.files.Image.name;  // ''
        var ImageFile = req.files.Image; // temporary file for the  buffer.
        // check for the if the file exists or not
        var ImagePath = 'public/images/' + ImageName;
        // move the temporary imagefile to a permanent location 
        ImageFile.mv(ImagePath, function(err){
            console.log(err);
        });
        // finding the data in database and updating  it
        var dataId = req.params.dataid;
        data.findOne({_id: dataId}).exec(function(err, data){
            // update the data and save
            data.Name = Name;
            data.Email = Email;
            data.Description = Description;
            data.ImageName = ImageName;
            data.save();
            res.render('thankyou', data); // render thankyou.ejs with the data from data
        });
        
    }
});

// settingup routes

myApp.get('/setup', function(req, res){

    let customerdata = [
        {
             customername: 'swetha', // ceredentials for login
            customerpassword: 'swetha'
        }
    ]
    customer.collection.insertMany(customerdata);
    res.send('data added');
});
//setiting  the port
myApp.listen(8020);
console.log('Everything executed fine.. website at port http://localhost:8020/');